import os
import imghdr
from PIL import Image
import logging
from tqdm import tqdm
import shutil

# 按PetImages文件架构更新数据集后需重新运行

def setup_logger():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('data_cleaning.log'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def check_image(filepath, min_size_kb=2):
    """
    综合检查图片是否有效
    1. 检查文件大小
    2. 检查JFIF头
    3. 使用imghdr检查文件类型
    4. 使用PIL验证图片完整性
    """
    try:
        # 检查文件大小
        if os.path.getsize(filepath) < min_size_kb * 1024:
            return False, "文件太小"
        
        # 检查JFIF头
        with open(filepath, 'rb') as f:
            header = f.read(10)
            if b'JFIF' not in header:
                return False, "非JFIF格式"
        
        # 使用imghdr检查
        img_type = imghdr.what(filepath)
        if img_type not in ['jpeg', 'jpg', 'png']:
            return False, f"不支持的图片类型: {img_type}"
        
        # 使用PIL验证
        with Image.open(filepath) as img:
            img.verify()
            # 验证图片是否可以加载
            img = Image.open(filepath)
            img.load()
            # 检查图片模式
            if img.mode not in ['RGB', 'RGBA']:
                return False, f"不支持的图片模式: {img.mode}"
            
        return True, "有效图片"
    
    except Exception as e:
        return False, f"验证失败: {str(e)}"

def clean_dataset(source_dir):
    """原地清理数据集并重命名图片"""
    logger = setup_logger()
    
    stats = {
        'total': {'cat': 0, 'dog': 0},
        'valid': {'cat': 0, 'dog': 0},
        'invalid': {'cat': 0, 'dog': 0},
        'errors': {}
    }
    
    logger.info(f"开始清理数据集: {source_dir}")
    
    # 处理Cat和Dog目录
    for category in ['Cat', 'Dog']:
        category_dir = os.path.join(source_dir, category)
        
        # 如果目录不存在，跳过
        if not os.path.exists(category_dir):
            logger.warning(f"目录不存在: {category_dir}")
            continue
        
        # 获取所有图片并验证
        valid_images = []
        logger.info(f"\n处理 {category} 目录...")
        
        for file in tqdm(os.listdir(category_dir), desc=f"验证{category}图片"):
            if not file.lower().endswith(('.jpg', '.jpeg', '.png')):
                continue
            
            filepath = os.path.join(category_dir, file)
            cat_type = category.lower()
            stats['total'][cat_type] += 1
            
            # 检查图片
            is_valid, reason = check_image(filepath)
            
            if is_valid:
                valid_images.append(filepath)
                stats['valid'][cat_type] += 1
            else:
                stats['invalid'][cat_type] += 1
                stats['errors'][reason] = stats['errors'].get(reason, 0) + 1
                logger.warning(f"删除无效图片 {filepath}: {reason}")
                os.remove(filepath)  # 删除无效图片
        
        # 重命名有效图片
        logger.info(f"重命名 {category} 目录中的有效图片...")
        for idx, old_path in enumerate(tqdm(valid_images)):
            directory = os.path.dirname(old_path)
            extension = os.path.splitext(old_path)[1]
            new_name = f"{idx}_{category.lower()}{extension}"
            new_path = os.path.join(directory, new_name)
            
            try:
                os.rename(old_path, new_path)
            except Exception as e:
                logger.error(f"重命名失败 {old_path}: {str(e)}")
    
    # 打印统计信息
    logger.info("\n" + "="*50)
    logger.info("数据清理完成！详细统计：")
    logger.info("="*50)
    
    # 分类别统计
    for category in ['cat', 'dog']:
        logger.info(f"\n{category.capitalize()}类图片统计:")
        logger.info(f"原始数量: {stats['total'][category]}")
        logger.info(f"有效数量: {stats['valid'][category]}")
        logger.info(f"删除数量: {stats['invalid'][category]}")
        try:
            logger.info(f"保留比例: {stats['valid'][category]/stats['total'][category]*100:.2f}%")
        except ZeroDivisionError:
            logger.info("保留比例: 0%")
    
    # 总体统计
    total_images = sum(stats['total'].values())
    valid_images = sum(stats['valid'].values())
    logger.info("\n总体统计:")
    logger.info(f"总图片数: {total_images}")
    logger.info(f"有效图片: {valid_images}")
    logger.info(f"删除图片: {total_images - valid_images}")
    logger.info(f"总体保留比例: {valid_images/total_images*100:.2f}%")
    
    # 错误类型统计
    logger.info("\n错误类型统计:")
    for reason, count in stats['errors'].items():
        logger.info(f"{reason}: {count}")

if __name__ == '__main__':
    source_dir = './PetImages'  # 数据集目录
    
    try:
        clean_dataset(source_dir)
    except Exception as e:
        logging.error(f"清理过程中出现错误: {str(e)}")
