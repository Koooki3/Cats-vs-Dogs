import os
import shutil
from tqdm import tqdm

def setup_train_directory():
    """
    将PetImages中的Cat和Dog目录下的图片统一复制到同级的train目录中
    保持原有的命名格式 (e.g., 0_cat.jpg, 1_dog.jpg)
    """
    source_dir = './PetImages'
    # 修改train目录位置，使其与PetImages同级
    train_dir = './train'
    
    # 确保目标目录存在
    os.makedirs(train_dir, exist_ok=True)
    
    # 复制图片计数器
    total_copied = 0
    errors = []
    
    print("开始整理数据集...")
    print(f"从 {source_dir} 复制图片到 {train_dir}")
    
    # 处理Cat和Dog目录
    for category in ['Cat', 'Dog']:
        category_dir = os.path.join(source_dir, category)
        
        if not os.path.exists(category_dir):
            print(f"警告: {category_dir} 目录不存在")
            continue
            
        print(f"\n处理 {category} 目录...")
        
        # 遍历并复制文件
        files = sorted(os.listdir(category_dir))  # 排序以确保顺序一致
        for file in tqdm(files, desc=f"复制{category}图片"):
            if not file.lower().endswith(('.jpg', '.jpeg', '.png')):
                continue
                
            source_path = os.path.join(category_dir, file)
            dest_path = os.path.join(train_dir, file)
            
            try:
                shutil.copy2(source_path, dest_path)
                total_copied += 1
            except Exception as e:
                errors.append(f"复制失败 {source_path}: {str(e)}")
    
    # 打印统计信息
    print("\n" + "="*50)
    print("数据集整理完成！")
    print(f"总共复制: {total_copied} 张图片")
    
    if errors:
        print("\n出现以下错误:")
        for error in errors:
            print(error)
    
    print("\n目录结构:")
    print("./")
    print("├── PetImages/")
    print("│   ├── Cat/")
    print("│   └── Dog/")
    print("└── train/")
    print(f"    └── {total_copied} 张图片")

if __name__ == '__main__':
    setup_train_directory()
